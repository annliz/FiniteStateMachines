
/**
 * Write a description of class FastExponentiation here.
 *
 * @author Annli
 * @version (a version number or a date)
 */
public class FastExponentiation
{
    public FastExponentiation()
    {
    }
    
    public static int exponentiate(int a, int b)
    {
        int x = a;
        int y = 1;
        int z = b;
        while (z != 0)
        {
            if (z%2 == 1)
            {
                y = x*y;
            }
            z = z/2;
            x = x*x;
        }
        return y;
    }

    public static void main(String[] args)
    {    
        
    }
}
