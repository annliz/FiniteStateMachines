import java.util.Scanner;

/**
 * Write a description of class FifteenGame here.
 *
 * @author Annli
 * @version (a version number or a date)
 */
public class FifteenGame
{
    public FifteenGame()
    {
    }

    public static int parity(int[] a, int row)
    {
        int ooo = 0;
        for (int i = 0; i < 15; i++)
        {
            for (int j = i+1; j < 15; j++)
            {
                if (a[i] < a[j])
                {
                    ooo++;
                }
            }
        }
        System.out.println("No. OOO Pairs: " + ooo);
        return (ooo + row)%2;
    }

    public static int[] toArray(int[][] game)
    {
        int[] a = new int[15];
        int index = 0;
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                if (game[i][j]!=0)
                {
                    a[index] = game[i][j];
                    index++;
                }
            }
        }
        return a;
    }

    public static void print(int[][] game)
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                System.out.print(game[i][j] + "\t"); 
            }
            System.out.println();
        }
    }

    public static void main(String[] args)
    {
        int[][] tiles = new int[4][4];
        int index = 15;
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                tiles[i][j] = index;
                index--;
            }
        }
        int row = 4;
        int column = 4;
        print(tiles);
        Scanner scan = new Scanner(System.in);
        String input = scan.nextLine();
        while (!input.equals("quit"))
        {
            if (input.equals("up") && row!=4)
            {
                tiles[row-1][column-1] = tiles[row][column-1];
                tiles[row][column-1] = 0;
                row = row+1;
            }
            else if (input.equals("down") && row!=1)
            {
                tiles[row-1][column-1] = tiles[row-2][column-1];
                tiles[row-2][column-1] = 0;
                row = row-1;
            }
            else if (input.equals("left") && column!=4)
            {
                tiles[row-1][column-1] = tiles[row-1][column];
                tiles[row-1][column] = 0;
                column = column+1;
            }
            else if (input.equals("right") && column!=1)
            {
                tiles[row-1][column-1] = tiles[row-1][column-2];
                tiles[row-1][column-2] = 0;
                column = column-1;
            }
            print(tiles);
            System.out.println("Row: " + row);
            System.out.println("Parity: " + parity(toArray(tiles), row));
            System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            input = scan.nextLine();
        }
    }
}
